from django.shortcuts import render

def home_view(request):
    """
    Normal basic home page for the project.
    """
    return render(request, 'home.html')
